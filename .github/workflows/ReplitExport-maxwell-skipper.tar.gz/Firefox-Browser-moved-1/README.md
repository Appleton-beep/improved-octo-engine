# Firefox Deployer

If you're reading this, obviously you forked. Hey LOL
Simply just click the green "Run" button. No other work required.